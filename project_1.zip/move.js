function move_menu(num){
    if (num==1){
        window.location.href="./breed.html"
    }
    else if(num==2){
        window.location.href="./behavior.html"
    }
    else if(num==3){
        window.location.href="./shelter.html"
    }
    else if(num==4){
        window.location.href="./book.html"
    }
    else if (num==5){
        window.location.href="./main.html"
    }
}